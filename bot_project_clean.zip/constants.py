"""
Global constants for the bot project.
"""

# Notification options (in minutes)
NOTIFICATION_OPTIONS = (15, 30, 60)
DEFAULT_NOTIFICATION_MINUTES = 30

# Pagination defaults
DEFAULT_PAGE_SIZE = 10
MAX_PAGE_SIZE = 100

# Booking constraints
MIN_BOOKING_ADVANCE_HOURS = 1  # Minimum hours in advance to book
MAX_BOOKING_ADVANCE_DAYS = 90  # Maximum days in advance to book
MAX_BOOKING_DURATION_HOURS = 24  # Maximum booking duration in hours

# Rate limiting
BOOKINGS_RATE_LIMIT = "5/minute"
AVAILABILITY_RATE_LIMIT = "20/minute"
HEALTH_CHECK_RATE_LIMIT = "60/minute"

# Age verification
MINIMUM_AGE = 18

# Booking statuses
BOOKING_STATUS_CONFIRMED = "CONFIRMED"
BOOKING_STATUS_ACTIVE = "ACTIVE"
BOOKING_STATUS_COMPLETED = "COMPLETED"
BOOKING_STATUS_CANCELLED = "CANCELLED"
BOOKING_STATUS_NO_SHOW = "NO_SHOW"

ACTIVE_BOOKING_STATUSES = [BOOKING_STATUS_CONFIRMED, BOOKING_STATUS_ACTIVE]

# Venue types
VENUE_TYPE_COMPUTER_CLUB = "computer_club"
VENUE_TYPE_RESTAURANT = "restaurant"

# Driver types
DRIVER_TYPE_MOCK = "MOCK"
DRIVER_TYPE_ICAFE = "ICAFE"
DRIVER_TYPE_RUNPAD = "RUNPAD"
DRIVER_TYPE_STANDALONE = "STANDALONE"
DRIVER_TYPE_SMARTSHELL = "SMARTSHELL"

# Cache TTL (in seconds)
CACHE_TTL_AVAILABILITY = 300  # 5 minutes

# Timezone
DEFAULT_TIMEZONE = "Asia/Tashkent"
