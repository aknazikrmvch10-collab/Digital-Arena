from fastapi import APIRouter, HTTPException, Header, Depends, Query, Request
from database import async_session_factory
from models import Club, Computer, User, Booking, RestaurantTable
from sqlalchemy import select, and_, func
from pydantic import BaseModel, field_validator
from datetime import datetime, timedelta
from utils.timezone import now_tashkent
from typing import Optional, List
from drivers.factory import DriverFactory
from services.redis_client import cache
from handlers.dependencies import get_current_user, verify_booking_owner, PaginationParams
from utils.limiter import limiter
from utils.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()

# --- Request Models ---
class BookingRequest(BaseModel):
    user_id: int # Telegram User ID
    club_id: int
    computer_id: str
    start_time: datetime
    duration_minutes: int
    
    @field_validator('club_id')
    @classmethod
    def validate_club_id(cls, v):
        if v <= 0:
            raise ValueError('Club ID must be positive')
        return v
    
    @field_validator('duration_minutes')
    @classmethod
    def validate_duration(cls, v):
        if v <= 0:
            raise ValueError('Duration must be greater than 0')
        if v > 24 * 60:  # Max 24 hours
            raise ValueError('Duration cannot exceed 24 hours')
        return v
    
    @field_validator('start_time')
    @classmethod
    def validate_start_time(cls, v):
        now = now_tashkent()
        # Allow bookings at least 1 hour in advance
        if v <= now + timedelta(hours=1):
            raise ValueError('Booking must be at least 1 hour in advance')
        # Max booking 90 days in advance
        if v > now + timedelta(days=90):
            raise ValueError('Booking cannot be more than 90 days in advance')
        return v
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

class AvailabilityRequest(BaseModel):
    club_id: int
    computer_id: str
    date: str # YYYY-MM-DD

# Note: get_current_user is now imported from handlers.dependencies

# --- Endpoints ---

@router.get("/health")
async def health_check():
    """
    Health Check endpoint для мониторинга состояния сервиса.
    Проверяет: БД, Redis.
    """
    import time
    start_time = time.time()
    
    health = {
        "status": "healthy",
        "timestamp": now_tashkent().isoformat(),
        "services": {}
    }
    
    # Check Database
    try:
        async with async_session_factory() as session:
            await session.execute(select(1))
        health["services"]["database"] = {"status": "ok"}
    except Exception as e:
        health["services"]["database"] = {"status": "error", "detail": str(e)}
        health["status"] = "degraded"
    
    # Check Redis
    redis_health = await cache.health_check()
    health["services"]["redis"] = redis_health
    if not redis_health.get("ok"):
        health["status"] = "degraded"
    
    health["response_time_ms"] = round((time.time() - start_time) * 1000, 2)
    
    # Return 503 if unhealthy
    if health["status"] != "healthy":
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content=health)
    
    return health

@router.get("/clubs")
async def get_clubs(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(10, ge=1, le=100, description="Items per page"),
    is_active: bool = Query(True, description="Show only active clubs")
):
    """Get clubs with pagination."""
    async with async_session_factory() as session:
        # Get total count
        count_query = select(func.count(Club.id)).where(Club.is_active == is_active)
        total = await session.scalar(count_query) or 0
        
        # Get paginated results
        result = await session.execute(
            select(Club)
            .where(Club.is_active == is_active)
            .order_by(Club.name.asc())
            .offset((page - 1) * limit)
            .limit(limit)
        )
        clubs = result.scalars().all()
        
        import math
        return {
            "clubs": [c.to_dict() for c in clubs],
            "page": page,
            "limit": limit,
            "total": total,
            "pages": math.ceil(total / limit) if total > 0 else 0
        }

@router.get("/clubs/{club_id}/computers")
async def get_items(
    club_id: int,
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page")
):
    """Get items (computers or tables) for a club with pagination."""
    async with async_session_factory() as session:
        club = await session.get(Club, club_id)
        if not club:
            raise HTTPException(status_code=404, detail="Club not found")
        
        venue_type = getattr(club, 'venue_type', 'computer_club')
        
        if venue_type == 'restaurant':
            # Get total count for restaurants
            count_query = select(func.count(RestaurantTable.id)).where(
                RestaurantTable.club_id == club_id
            )
            total = await session.scalar(count_query) or 0
            
            # Get paginated tables
            result = await session.execute(
                select(RestaurantTable)
                .where(RestaurantTable.club_id == club_id)
                .order_by(RestaurantTable.name.asc())
                .offset((page - 1) * limit)
                .limit(limit)
            )
            tables = result.scalars().all()
            
            items = []
            for t in tables:
                item = t.to_dict()
                # Polyfill missing fields for frontend compatibility
                item['price_per_hour'] = t.booking_price
                item['cpu'] = f"Мест: {t.seats}"
                item['gpu'] = f"Депозит: {t.min_deposit}"
                item['ram_gb'] = 0
                item['monitor_hz'] = 0
                item['venue_type'] = 'restaurant'
                items.append(item)
            
            import math
            return {
                "items": items,
                "page": page,
                "limit": limit,
                "total": total,
                "pages": math.ceil(total / limit) if total > 0 else 0
            }
        else:
            # Get total count for computers
            count_query = select(func.count(Computer.id)).where(
                Computer.club_id == club_id
            )
            total = await session.scalar(count_query) or 0
            
            # Get paginated computers
            result = await session.execute(
                select(Computer)
                .where(Computer.club_id == club_id)
                .order_by(Computer.zone.asc(), Computer.name.asc())
                .offset((page - 1) * limit)
                .limit(limit)
            )
            computers = result.scalars().all()
            
            items = []
            for c in computers:
                item = c.to_dict()
                item['venue_type'] = 'computer_club'
                items.append(item)
            
            import math
            return {
                "items": items,
                "page": page,
                "limit": limit,
                "total": total,
                "pages": math.ceil(total / limit) if total > 0 else 0
            }

@router.post("/bookings")
@limiter.limit("5/minute")
async def create_booking(booking: BookingRequest, request: Request, user_data: dict = Depends(get_current_user)):
    """
    Create a new booking with race condition protection.
    Securely uses user_id from Telegram validation.
    """
    # Overwrite user_id with authenticated ID
    booking.user_id = user_data["id"]
    
    async with async_session_factory() as session:
        # ✅ FIX: Wrap entire booking process in transaction
        async with session.begin():
            # Get club (no lock needed, club data doesn't change during booking)
            club = await session.get(Club, booking.club_id)
            if not club:
                raise HTTPException(status_code=404, detail="Club not found")
            
            venue_type = getattr(club, 'venue_type', 'computer_club')
                
            # Get or create user
            logger.info("Booking Request", booking=booking.dict())
            
            result = await session.execute(select(User).where(User.tg_id == booking.user_id))
            user = result.scalars().first()
            
            if not user:
                logger.info(f"User {booking.user_id} not found, creating new.")
                user = User(tg_id=booking.user_id, full_name="WebApp User")
                session.add(user)
                await session.flush()  # ✅ Use flush instead of commit (stays in transaction)
                await session.refresh(user)
            
            # Ensure start_time is naive
            booking_start_naive = booking.start_time if booking.start_time.tzinfo else booking.start_time
            
            # Verify item exists and get its name
            if venue_type == 'restaurant':
                item = await session.get(RestaurantTable, int(booking.computer_id))
                if not item:
                    raise HTTPException(status_code=404, detail="Table not found")
            else:
                # Computer Club
                item = await session.get(Computer, int(booking.computer_id))
                if not item:
                    raise HTTPException(status_code=404, detail="Computer not found")
            
            # Initialize driver and reserve
            # Note: Driver's reserve_pc is now inside this transaction,
            # so its conflict checks will be protected by transaction isolation
            try:
                driver = DriverFactory.get_driver(
                    club.driver_type, 
                    {"club_id": club.id, **club.connection_config}
                )
                
                result = await driver.reserve_pc(
                    pc_id=booking.computer_id,
                    user_id=user.id,
                    start_time=booking_start_naive,
                    duration_minutes=booking.duration_minutes
                )
                
                if result.success:
                    logger.info("Booking success", booking_id=result.booking_id)
                    # Transaction will auto-commit at end of 'async with session.begin()'
                    return {
                        "success": True, 
                        "message": result.message, 
                        "booking_id": result.booking_id
                    }
                else:
                    logger.warning("Booking failed", message=result.message)
                    # Transaction will auto-rollback since we're not committing
                    raise HTTPException(
                        status_code=409,
                        detail=result.message or "Booking conflict - time slot unavailable"
                    )
                    
            except HTTPException:
                raise  # Re-raise HTTP exceptions
            except ValueError as e:
                logger.error("Invalid booking parameters", error=str(e))
                raise HTTPException(status_code=422, detail=f"Invalid parameters: {str(e)}")
            except Exception as e:
                # Transaction will auto-rollback on exception
                logger.error("Booking Exception", error=str(e), exc_info=True)
                raise HTTPException(status_code=500, detail="Booking failed - please try again later")

@router.get("/availability")
@limiter.limit("20/minute")
async def check_availability(
    club_id: int = Query(..., gt=0, description="Club ID"),
    computer_id: str = Query(..., description="Computer or Table ID"),
    date: str = Query(..., description="Date in YYYY-MM-DD format"),
    request: Request = None
):
    """Check availability for an item on a specific date."""
    # Validate date format
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD")
    
    # Validate date is not in the past
    if target_date < now_tashkent().date():
        raise HTTPException(status_code=400, detail="Cannot check availability for past dates")

    async with async_session_factory() as session:
        club = await session.get(Club, club_id)
        if not club:
            raise HTTPException(status_code=404, detail="Club not found")
        
        venue_type = getattr(club, 'venue_type', 'computer_club')
        
        # Validate and resolve item
        try:
            computer_id_int = int(computer_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Компьютер ID должен быть числом")
        
        item_name = ""
        if venue_type == 'restaurant':
            item = await session.get(RestaurantTable, computer_id_int)
            if not item:
                raise HTTPException(status_code=404, detail="Table not found")
            item_name = item.name
        else:
            item = await session.get(Computer, computer_id_int)
            if not item:
                raise HTTPException(status_code=404, detail="Computer not found")
            item_name = item.name

        # Query Bookings
        result = await session.execute(
            select(Booking).where(
                and_(
                    Booking.club_id == club_id,
                    Booking.computer_name == item_name,
                    Booking.status.in_(["CONFIRMED", "ACTIVE"])
                )
            )
        )
        bookings = result.scalars().all()
        
        occupied_hours = set()
        for b in bookings:
            for hour in range(24):
                check_time = datetime.combine(target_date, datetime.min.time().replace(hour=hour))
                check_end = check_time + timedelta(hours=1)
                
                if (b.start_time < check_end) and (b.end_time > check_time):
                    occupied_hours.add(hour)
                    
        return {"occupied_hours": sorted(list(occupied_hours))}

@router.get("/user/bookings")
async def get_user_bookings(
    request: Request,
    user_data: dict = Depends(get_current_user),
    pagination: PaginationParams = Depends()
):
    """Get active and future bookings for a user with pagination."""
    user_id = user_data["id"]
    async with async_session_factory() as session:
        # Get total count first
        count_query = select(func.count(Booking.id)).join(
            User, Booking.user_id == User.id
        ).where(
            and_(
                User.tg_id == user_id,
                Booking.status == "CONFIRMED",
                Booking.end_time > now_tashkent()
            )
        )
        total = await session.scalar(count_query) or 0
        
        # Get paginated results
        result = await session.execute(
            select(Booking, Club).join(Club, Booking.club_id == Club.id).join(
                User, Booking.user_id == User.id
            ).where(
                and_(
                    User.tg_id == user_id,
                    Booking.status.in_(["CONFIRMED", "ACTIVE"]),
                    Booking.end_time > now_tashkent()
                )
            ).order_by(Booking.start_time.asc())
            .offset(pagination.offset)
            .limit(pagination.limit)
        )
        
        from datetime import timezone, timedelta
        rows = result.all()
        bookings = []
        for booking, club in rows:
            tz = timezone(timedelta(hours=5))
            display_start = booking.start_time.astimezone(tz).strftime("%d.%m %H:%M")
            display_end = booking.end_time.astimezone(tz).strftime("%H:%M")
            
            bookings.append({
                "id": booking.id,
                "club_name": club.name,
                "computer_name": booking.computer_name,
                "start_time": booking.start_time.isoformat(),
                "display_time": f"{display_start} - {display_end}",
                "status": booking.status,
                "total_price": 0
            })
        
        import math
        return {
            "bookings": bookings,
            "page": pagination.page,
            "limit": pagination.limit,
            "total": total,
            "pages": math.ceil(total / pagination.limit) if total > 0 else 0
        }


@router.delete("/bookings/{booking_id}")
async def cancel_booking(
    booking_id: int,
    user_data: dict = Depends(get_current_user)
):
    """
    Cancel a booking (owner only).
    Uses IDOR protection via user verification.
    """
    if booking_id <= 0:
        raise HTTPException(status_code=400, detail="Invalid booking ID")
    
    user_id = user_data["id"]
    
    try:
        async with async_session_factory() as session:
            async with session.begin():
                # Find user
                user_result = await session.execute(
                    select(User).where(User.tg_id == user_id)
                )
                user = user_result.scalars().first()
                
                if not user:
                    raise HTTPException(status_code=404, detail="User not found")
                
                # Find booking with ownership check (IDOR protection)
                result = await session.execute(
                    select(Booking).where(
                        and_(
                            Booking.id == booking_id,
                            Booking.user_id == user.id
                        )
                    )
                )
                booking = result.scalars().first()
                
                if not booking:
                    raise HTTPException(
                        status_code=404,
                        detail="Booking not found or access denied"
                    )
                
                if booking.status != "CONFIRMED":
                    raise HTTPException(
                        status_code=400,
                        detail="Only confirmed bookings can be cancelled"
                    )
                
                # Check if booking is too close to start time (within 1 hour)
                time_until_booking = (booking.start_time - now_tashkent()).total_seconds() / 3600
                if time_until_booking < 1:
                    raise HTTPException(
                        status_code=400,
                        detail="Cannot cancel bookings within 1 hour of start time"
                    )
                
                booking.status = "CANCELLED"
                await session.flush()
                
                logger.info("Booking cancelled", booking_id=booking_id, user_id=user.id)
                
                return {
                    "success": True,
                    "message": f"Booking #{booking_id} cancelled successfully"
                }
    
    except HTTPException:
        raise  # Re-raise HTTP exceptions
    except Exception as e:
        logger.error("Error cancelling booking", booking_id=booking_id, error=str(e), exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to cancel booking - please try again")


# =======================================
# WEB AUTH ENDPOINTS (phone-based login)
# =======================================

class WebLoginRequest(BaseModel):
    phone: str

from jose import jwt, JWTError
import os

_JWT_SECRET = os.getenv("SECRET_KEY", "CHANGE_ME_USE_STRONG_SECRET_IN_PRODUCTION")
_JWT_ALGORITHM = "HS256"

def _make_web_token(user_id: int, tg_id: int) -> str:
    """Create a signed JWT token. Cannot be forged without knowing SECRET_KEY."""
    payload = {"user_id": user_id, "tg_id": tg_id}
    return jwt.encode(payload, _JWT_SECRET, algorithm=_JWT_ALGORITHM)

def _parse_web_token(token: str) -> dict | None:
    """Parse and VERIFY a JWT token. Returns None if invalid or tampered."""
    try:
        payload = jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALGORITHM])
        return payload
    except JWTError:
        return None

async def get_web_user(request: Request) -> dict:
    """Get current web user from Authorization header."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Требуется авторизация")
    
    token = auth_header[7:]
    payload = _parse_web_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Недействительный токен")
    
    async with async_session_factory() as session:
        result = await session.execute(select(User).where(User.id == payload["user_id"]))
        user = result.scalars().first()
        if not user:
            raise HTTPException(status_code=401, detail="Пользователь не найден")
        return {"user_id": user.id, "tg_id": user.tg_id, "name": user.full_name}


@router.post("/web/login")
async def web_login(data: WebLoginRequest):
    """Login by phone number. Returns token if user exists."""
    phone = data.phone.strip().replace("+", "")
    
    async with async_session_factory() as session:
        # Search by phone (stored without +) 
        result = await session.execute(
            select(User).where(User.phone.ilike(f"%{phone[-9:]}%"))
        )
        user = result.scalars().first()
        
        if not user:
            raise HTTPException(status_code=404, detail="Номер не найден. Зарегистрируйтесь через Telegram-бота @ArenaSlotBot")
        
        token = _make_web_token(user.id, user.tg_id)
        return {
            "token": token,
            "user": {
                "id": user.id,
                "tg_id": user.tg_id,
                "name": user.full_name or user.username or "User",
                "phone": user.phone
            }
        }


@router.get("/web/me")
async def web_me(request: Request):
    """Get current user info from token."""
    user_data = await get_web_user(request)
    
    async with async_session_factory() as session:
        result = await session.execute(select(User).where(User.id == user_data["user_id"]))
        user = result.scalars().first()
        
        return {
            "id": user.id,
            "tg_id": user.tg_id,
            "name": user.full_name or user.username or "User",
            "phone": user.phone
        }


@router.get("/web/bookings")
async def web_user_bookings(request: Request):
    """Get bookings for authenticated web user."""
    user_data = await get_web_user(request)
    
    async with async_session_factory() as session:
        now = now_tashkent()
        result = await session.execute(
            select(Booking)
            .where(
                and_(
                    Booking.user_id == user_data["user_id"],
                    Booking.status.in_(["CONFIRMED", "ACTIVE"])
                )
            )
            .order_by(Booking.start_time.desc())
            .limit(20)
        )
        bookings = result.scalars().all()
        
        from datetime import timezone, timedelta
        tz = timezone(timedelta(hours=5))
        items = []
        for b in bookings:
            # Get club name
            club = await session.get(Club, b.club_id)
            
            # ✅ FIX #3: Booking model has `end_time` directly, not `duration_minutes` or `computer_id`
            items.append({
                "id": b.id,
                "club_name": club.name if club else "Unknown",
                "computer_name": b.computer_name or "Unknown PC",
                "display_time": f"{b.start_time.astimezone(tz).strftime('%d.%m %H:%M')} — {b.end_time.astimezone(tz).strftime('%H:%M')}",
                "status": b.status,
                "start_time": b.start_time.isoformat()
            })
        
        return items


@router.delete("/web/bookings/{booking_id}")
async def web_cancel_booking(booking_id: int, request: Request):
    """Cancel a booking for authenticated web user."""
    user_data = await get_web_user(request)
    
    async with async_session_factory() as session:
        result = await session.execute(
            select(Booking).where(
                and_(
                    Booking.id == booking_id,
                    Booking.user_id == user_data["user_id"]
                )
            )
        )
        booking = result.scalars().first()
        
        if not booking:
            raise HTTPException(status_code=404, detail="Бронь не найдена")
        
        if booking.status not in ("CONFIRMED", "ACTIVE"):
            raise HTTPException(status_code=400, detail="Нельзя отменить эту бронь")
        
        booking.status = "CANCELLED"
        await session.commit()
        
        return {"success": True, "message": "Бронь отменена"}

